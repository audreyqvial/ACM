# ACM — Étude d'impact comparative (auto-générée)

**Généré le :** 2026-08-06 10:10:05 CEST

> Compare deux façons de répondre à « si je modifie cet ACI, qu'est-ce qui est affecté ? » : investigation manuelle vs propagation ACM. Chiffres dérivés de l'exécution, jamais codés en dur.

## Cas d'étude

Changement du composant partagé `aci:model:shared-llm` dans un système de 13 ACI et 18 relations.

## Résultats

| Métrique | Investigation manuelle | Investigation ACM |
|---|---|---|
| Items affectés identifiés | 9 (exhaustif) | 9 |
| Coût | 10 inspections | 1 requête |
| Profondeur de propagation | 2 niveaux | 3 itérations (point-fixe) |

## Le risque de l'investigation naïve

Une investigation manuelle qui s'arrête aux dépendants directs (1 niveau) n'identifie que **6** des **9** items réellement affectés — elle en **manque 3** :

- `aci:workflow:w0`
- `aci:workflow:w1`
- `aci:workflow:w2`

Ces items sont affectés *indirectement* : ils dépendent d'un ACI qui dépend lui-même du composant changé. C'est précisément le type d'effet qu'une investigation manuelle rate.

## Validation croisée

L'ensemble affecté calculé par ACM **coïncide exactement** avec l'investigation manuelle exhaustive : ACM ne fabrique aucun faux positif et ne manque aucun effet. La différence est le **coût** et la **fiabilité** : ACM garantit l'exhaustivité en une propagation, là où l'investigation manuelle exige une discipline transitive parfaite.

---

*Rapport généré automatiquement — 2026-08-06T10:10:05.682398+02:00*